package com.alianhome.batterystate;

import com.unity3d.player.*;

import android.content.Intent;
import android.content.IntentFilter;

public class MainActivity extends UnityPlayerActivity {

	
	/** ��ȡ��ص�״̬�͵���ֵ
	 * @return
	 */
	public static String GetBatteryState() { 
		IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);

		Intent intent = UnityPlayer.currentActivity.registerReceiver(null,
				ifilter);
		int rawlevel = intent.getIntExtra("level", 0);
		int scale = intent.getIntExtra("scale", 0);
		int status = intent.getIntExtra("status", 0);

		int batteryPercent = -1;

		if ((rawlevel > 0) && (scale > 0)) {
			batteryPercent = rawlevel * 100 / scale;
		} else {
			batteryPercent = 55;
		}
		String jsonString = "{\"status\":" + status + ",\"value\":"
				+ batteryPercent + "}";
		return jsonString;
	}
}
